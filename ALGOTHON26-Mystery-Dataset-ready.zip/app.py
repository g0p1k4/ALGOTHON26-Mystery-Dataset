
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.ensemble import IsolationForest, RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error

st.set_page_config(page_title="MysteryLens AI", page_icon="🔎", layout="wide")

@st.cache_data
def demo_data():
    rng = np.random.default_rng(42)
    n = 650
    regions = rng.choice(["North","South","East","West"], n)
    categories = rng.choice(["Electronics","Home","Grocery","Fashion"], n)
    age = rng.integers(18, 65, n)
    income = np.maximum(18000, rng.normal(52000, 17000, n)).round(0)
    visits = rng.poisson(7, n) + 1
    spend = np.maximum(80, income/900 + visits*rng.normal(115, 25, n) + rng.normal(0, 180, n)).round(2)
    discount = np.clip(rng.normal(12, 6, n), 0, 35).round(1)
    satisfaction = np.clip(3.1 + visits*0.08 - discount*0.025 + rng.normal(0, .55, n), 1, 5).round(1)
    returned = ((discount > 25) & (satisfaction < 2.8) | (rng.random(n) < .07)).astype(int)
    df = pd.DataFrame({"Region":regions,"Category":categories,"Age":age,"Income":income,
                       "Visits":visits,"Spend":spend,"Discount":discount,
                       "Satisfaction":satisfaction,"Returned":returned})
    idx = rng.choice(df.index, 8, replace=False)
    df.loc[idx, "Spend"] *= rng.uniform(3.5, 6.0, len(idx))
    df.loc[idx, "Visits"] += rng.integers(20, 50, len(idx))
    return df

def clean_df(df):
    out = df.copy()
    out.columns = [str(c).strip().replace(" ", "_") for c in out.columns]
    out = out.drop_duplicates()
    for c in out.select_dtypes(include=np.number).columns:
        out[c] = pd.to_numeric(out[c], errors="coerce")
        out[c] = out[c].fillna(out[c].median())
    for c in out.select_dtypes(exclude=np.number).columns:
        mode = out[c].mode()
        out[c] = out[c].fillna(mode.iloc[0] if len(mode) else "Unknown")
    return out

def anomaly_detection(df):
    nums = df.select_dtypes(include=np.number).columns.tolist()
    if len(nums) < 2:
        return pd.Series(False, index=df.index), "Not enough numeric variables."
    X = df[nums].replace([np.inf,-np.inf], np.nan).fillna(df[nums].median())
    contamination = min(0.08, max(0.02, 10/max(len(df),100)))
    labels = IsolationForest(n_estimators=180, contamination=contamination, random_state=42).fit_predict(X)
    mask = labels == -1
    return pd.Series(mask,index=df.index), f"{int(mask.sum())} observations were flagged as unusual."

def relationship(df):
    nums = df.select_dtypes(include=np.number).columns.tolist()
    if len(nums) < 2: return "Add at least two numeric variables to discover relationships."
    corr = df[nums].corr()
    pairs=[]
    for i,a in enumerate(nums):
        for b in nums[i+1:]:
            if pd.notna(corr.loc[a,b]): pairs.append((abs(corr.loc[a,b]),corr.loc[a,b],a,b))
    pairs.sort(reverse=True)
    if not pairs: return "No measurable numeric relationship was found."
    _,v,a,b=pairs[0]
    strength="strong" if abs(v)>=.7 else "moderate" if abs(v)>=.4 else "weak"
    direction="positive" if v>0 else "negative"
    return f"The strongest detected relationship is a **{strength} {direction} association** between `{a}` and `{b}` (r = {v:.2f})."

def predictive_lens(df,target):
    X=df.drop(columns=[target]).copy()
    y=df[target].copy()
    for c in X.columns:
        if X[c].dtype=="object":
            X[c]=LabelEncoder().fit_transform(X[c].astype(str))
    X=X.replace([np.inf,-np.inf],np.nan).fillna(0)
    if y.dtype=="object" or y.nunique()<=8 and not pd.api.types.is_float_dtype(y):
        y=LabelEncoder().fit_transform(y.astype(str))
        model=RandomForestClassifier(n_estimators=140,random_state=42)
        metric="Accuracy"
    else:
        model=RandomForestRegressor(n_estimators=140,random_state=42)
        metric="MAE"
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.22,random_state=42)
    model.fit(Xtr,ytr); pred=model.predict(Xte)
    score=accuracy_score(yte,pred) if metric=="Accuracy" else mean_absolute_error(yte,pred)
    imp=pd.DataFrame({"Feature":X.columns,"Importance":model.feature_importances_}).sort_values("Importance",ascending=False)
    return metric,score,imp

st.title("🔎 MysteryLens AI")
st.caption("ALGOTHON'26 • ALG-DATA-01 • Automated data investigation, anomaly discovery & predictive insight")

with st.sidebar:
    st.header("Data Input")
    uploaded=st.file_uploader("Upload a CSV dataset",type=["csv"])
    use_demo=st.toggle("Use built-in demo dataset",value=uploaded is None)
    st.divider()
    st.write("**Investigation pipeline**")
    st.write("Clean → Explore → Detect → Explain → Predict")

if uploaded is not None and not use_demo:
    raw=pd.read_csv(uploaded); source=uploaded.name
else:
    raw=demo_data(); source="Built-in Mystery Demo Dataset"

before=len(raw)
df=clean_df(raw)
anomaly_mask,msg=anomaly_detection(df)
df["_Anomaly"]=np.where(anomaly_mask,"Anomaly","Normal")

st.success(f"Loaded **{source}** • {len(df):,} rows × {df.shape[1]-1:,} original columns")
c1,c2,c3,c4=st.columns(4)
c1.metric("Records",f"{len(df):,}")
c2.metric("Variables",f"{df.shape[1]-1}")
c3.metric("Duplicates removed",f"{before-len(df)}")
c4.metric("Anomalies",f"{int(anomaly_mask.sum())}")

overview,rel,anom,pred,find=st.tabs(["🧭 Overview","📊 Relationships","🚨 Anomalies","🤖 Predictive Lens","💡 Findings"])

with overview:
    st.subheader("Dataset fingerprint")
    st.dataframe(df.head(12),use_container_width=True)
    nums=df.select_dtypes(include=np.number).columns.tolist()
    if nums:
        col=st.selectbox("Explore a numeric variable",nums)
        st.plotly_chart(px.histogram(df,x=col,color="_Anomaly",marginal="box",title=f"Distribution of {col}"),use_container_width=True)

with rel:
    st.subheader("What moves together?")
    st.info(relationship(df))
    nums=df.select_dtypes(include=np.number).columns.tolist()
    if len(nums)>=2:
        st.plotly_chart(px.imshow(df[nums].corr(),text_auto=".2f",aspect="auto",title="Correlation Map"),use_container_width=True)
        x=st.selectbox("X variable",nums,key="x"); y=st.selectbox("Y variable",nums,index=min(1,len(nums)-1),key="y")
        st.plotly_chart(px.scatter(df,x=x,y=y,color="_Anomaly",title=f"{x} vs {y}"),use_container_width=True)

with anom:
    st.subheader("🚨 Automated anomaly detector")
    st.write(msg)
    st.dataframe(df[df["_Anomaly"]=="Anomaly"].drop(columns=["_Anomaly"]),use_container_width=True)
    nums=df.select_dtypes(include=np.number).columns.tolist()
    if len(nums)>=2:
        st.plotly_chart(px.scatter(df,x=nums[0],y=nums[1],color="_Anomaly",title="Normal vs unusual observations"),use_container_width=True)

with pred:
    st.subheader("🤖 Predictive Lens")
    choices=[c for c in df.columns if c!="_Anomaly"]
    target=st.selectbox("Choose a target",choices,index=len(choices)-1)
    try:
        metric,score,imp=predictive_lens(df.drop(columns=["_Anomaly"]),target)
        st.metric("Hold-out "+metric, f"{score*100:.1f}%" if metric=="Accuracy" else f"{score:.3f}")
        st.plotly_chart(px.bar(imp.head(10),x="Importance",y="Feature",orientation="h",title="Top predictive drivers"),use_container_width=True)
    except Exception as e:
        st.warning("This target cannot be modeled automatically. Choose another column.")

with find:
    st.subheader("💡 Evidence-backed findings")
    findings=[
        f"**Data quality:** {before-len(df)} duplicate rows were removed and missing numeric/categorical values were filled using robust defaults.",
        f"**Anomaly signal:** {msg}",
        f"**Relationship:** {relationship(df)}"
    ]
    for f in findings: st.markdown(f)
    st.download_button("⬇️ Download cleaned dataset",df.drop(columns=["_Anomaly"]).to_csv(index=False),"cleaned_dataset.csv","text/csv")

st.divider()
st.caption("AI-assisted development was used and is disclosed in the README.")
