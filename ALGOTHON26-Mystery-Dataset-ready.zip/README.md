# 🔎 MysteryLens AI — ALGOTHON'26

**Problem:** ALG-DATA-01 — The Mystery Dataset

MysteryLens AI is an interactive data-investigation application that turns an unfamiliar CSV into a structured investigation. It automatically cleans data, profiles variables, discovers relationships, flags unusual observations, generates evidence-backed findings, and builds a compact predictive model.

## Key features
- Upload any CSV and investigate it immediately
- Automatic cleaning and duplicate handling
- Dataset fingerprint and data-quality metrics
- Interactive correlation map and relationship explorer
- Isolation Forest anomaly detection
- Evidence-backed finding panel
- Random Forest predictive lens with feature importance
- Download cleaned data
- Built-in demo dataset for immediate demonstration

## Technology
Python, Streamlit, Pandas, NumPy, Scikit-learn, Plotly.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Structure
```text
ALGOTHON26-Mystery-Dataset/
├── app.py
├── requirements.txt
├── README.md
└── data/
    └── mystery_demo.csv
```

## Dataset disclosure
The repository contains a synthetic demo dataset so the application can run independently. The app accepts CSV uploads, so the official mystery dataset can be analyzed without changing the application.

## AI assistance disclosure
AI assistance was used for code drafting, debugging support, and documentation. The final workflow, structure, and application behavior were reviewed and assembled for the hackathon.

## Limitations
- Automatic modeling is intentionally lightweight.
- Correlation does not imply causation.
- Rare legitimate cases can be flagged as anomalies.
- Predictive quality depends on the supplied dataset.

## Future improvements
- Natural-language investigation reports
- Cross-validation and more model families
- Explainable AI with SHAP
- Experiment tracking
- One-click deployment
